<?php

const PUSHERAPP_APPID = '';
const PUSHERAPP_AUTHKEY = '';
const PUSHERAPP_SECRET = '';
const PUSHERAPP_CLUSTER = 'eu';
const TEST_CHANNEL = 'my-channel';
const CHANNEL_PREFIX = 'my-';
